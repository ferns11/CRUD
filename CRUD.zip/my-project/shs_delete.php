<?php
if(isset($_GET['id'])){

    
    $servername="localhost";
    $username="root";
    $password="";
    $database="student_infos";
    
    $conn = new mysqli($servername, $username, $password, $database);

    $sql = "DELETE FROM student WHERE id = " . $_GET['id'];
    $result = $conn->query($sql);

}

header("Location: /my-project/shs_list.php");
exit;

?>

    if(isset($_GET['id'])){
        echo "<script>
            if (confirm('Are you sure you want to delete?')) {
                var id = ".$_GET['id'].";
                window.location.href = 'shs_delete.php?id=' + id;
            } else {
                window.location.href = 'shs_list.php';
            }
            </script>";
    }
