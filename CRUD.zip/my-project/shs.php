<?php
//connect ang DB
$servername="localhost";
$username="root";
$password="";
$database="student_infos";
$conn = new mysqli($servername, $username, $password, $database);

//define ang varia
$name ="";
$email ="";
$address ="";
$contact ="";
$strand ="";

$errormessage ="";
$successmessage = "";

//basta ma post AHHAHAHAHAHSDA
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $name = $_POST ['Name'];
    $email = $_POST ['Email'];
    $address = $_POST ['Address'];
    $contact = $_POST ['Contact'];
    $strand = $_POST ['Strand'];

//dri kay murag kuan mag display ug error message basta dininimo i fill up ang form
    do{
if (empty($name) || empty($email) || empty($address) || empty($contact) || empty($strand)) {

    $errormessage = "Please fill up all fields";
    break;  
}
    $sql = "SELECT * FROM student WHERE email = '$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $errormessage = "Email already exists. Please try another email";
        break;
    }
//insert sa ug student sa DB
$sql = "INSERT INTO student (name, email, address, contact, strand) ".
        "VALUES ('$name', '$email', '$address', '$contact', '$strand')";
$result = $conn->query($sql);

if (!$result) {
    $errormessage = "Error: " . $conn->error;
    break;
}


    $name ="";
    $email ="";
    $address ="";
    $contact ="";
    $strand ="";

    $successmessage = "Student added successfully";

    //kani para ma redirect sa shs_list.php
    header("Location: /my-project/shs_list.php");
    exit;


    } while (false);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University of Mindanao SHS</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</head> 
<body>
    <div class="container my-5">
        <h2>New Student</h2>

        <?php 
        if (!empty($errormessage)){
            echo "
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                <strong>$errormessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";

            
        }       
        ?>

        <form method="post">
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Name" required value="<?php echo $name; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Email" required value="<?php echo $email; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Address</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Address" required value="<?php echo $address; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Contact</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Contact" required value="<?php echo $contact; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">STRAND</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Strand" required value="<?php echo $strand; ?>">
                </div>
            </div>

            <?php 
        if (!empty($successmessage)){
            echo "
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                <strong>$successmessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";

            
        }       
        ?>

            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="/my-project/shs_list.php" role="button">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>

