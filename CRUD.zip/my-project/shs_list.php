<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STUDENT INFORMATION</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>
            List of Students
            <a class="btn btn-info" href="shs.php" role="button">New Student</a>
        </h2>
        <table class="table">
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Strand</th>
                <th>Created At</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php
                $servername="localhost";
                $username="root";
                $password="";
                $database="student_infos";

                $conn = new mysqli($servername, $username, $password, $database);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT * FROM student";
                $result = $conn->query($sql);

                if (!$result) {
                    die("Invalid query: " . $conn->error);
                }

                while($row =$result->fetch_assoc()){
                    echo "
                                   
                    <tr>
                    <td>$row[id]</td>                
                    <td>$row[name]</td>
                    <td>$row[email]</td>
                    <td>$row[address]</td>
                    <td>$row[contact]</td>
                    <td>$row[strand]</td>
                    <td>$row[created_at]</td>
                    <td>
                    <a class='btn btn-success btn-sm' href='EDIT.php?id=$row[id]'>Edit</a>
                    <a class='btn btn-danger btn-sm' href='./shs_delete.php?id=$row[id]'>Delete</a>
                    </td>
                </tr>
                    ";
                }
                ?>  

            </tbody>
        </table>
    </div>
</body>
</html>