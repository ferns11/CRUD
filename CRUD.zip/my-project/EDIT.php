<?php
$servername="localhost";
$username="root";
$password="";
$database="student_infos";
$conn = new mysqli($servername, $username, $password, $database);


$id= "";
$name= "";
$email= "";
$address= "";
$contact= "";
$strand= "";

$errormessage= "";
$successmessage= "";

if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    
    if(!isset($_GET["id"])){
        header("location: /my-project/shs_list.php");
        exit;
    }
        $id = $_GET["id"];   
    
        $sql = "SELECT * FROM student WHERE id = $id";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        if(!$row){
            header("Location: /my-project/shs_list.php");
            exit;
        }

        $name = $row['name'];
        $email = $row['email'];
        $address = $row['address'];
        $contact = $row['contact'];
        $strand = $row['strand'];

    }
    else {
        $id = $_POST['id'];
        $name = $_POST['Name'];
        $email = $_POST['Email'];
        $address = $_POST['Address'];
        $contact = $_POST['Contact'];
        $strand = $_POST['Strand'];

        do{
            if (empty($name) || empty($email) || empty($address) || empty($contact) || empty($strand)) {
                $errormessage = "All fields are required. Please fill up all fields";
                break;
            }

            $sql = "UPDATE student " .
            "SET Name = '$name', Email = '$email', Address = '$address', Contact = '$contact', Strand = '$strand' " .
            "WHERE id = $id";

            $result = $conn->query($sql);

            if(!$result){
                $errormessage = "Error: " . $conn->error;
                break;
            }

            $successmessage = "Student updated successfully";

            header("Location: /my-project/shs_list.php");
            exit;

    } while(false);
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University of Mindanao SHS</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</head> 
<body>
    <div class="container my-5">
        <h2>New Student</h2>

        <?php 
        if (!empty($errormessage)){
            echo "
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                <strong>$errormessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";

            
        }       
        ?>

        <form method="post">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Name" required value="<?php echo $name; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Email" required value="<?php echo $email; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Address</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Address" required value="<?php echo $address; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Contact</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Contact" required value="<?php echo $contact; ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">STRAND</label>
                <div class="col-sm-6">
                <input type="text" class="form-control" name="Strand" required value="<?php echo $strand; ?>">
                </div>
            </div>

            <?php 
        if (!empty($successmessage)){
            echo "
            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                <strong>$successmessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";

            
        }       
        ?>

                <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-danger" href="/my-project/shs_list.php" role="button">Cancel</a>
                </div>
        </form>
    </div>
</body>
</html>

